export default function Cancel({ t }) {
  return (
    <div>
      <h2>{t.cancelTitle}</h2>
      <p>{t.cancelSubtitle}</p>
    </div>
  );
}
